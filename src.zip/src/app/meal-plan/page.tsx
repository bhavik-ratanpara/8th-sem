'use client';

import { useState, useEffect, Suspense } from 'react';
import { ProtectedRoute } from '@/components/protected-route';
import { useUser } from '@/firebase';
import { 
  saveMealPlan, 
  getMealPlan, 
  saveGroceryList,
  deleteGrocerySection,
  type WeeklyMealPlan, 
  type DayPlan, 
  type MealSlot,
  type GroceryItem,
  type GrocerySection
} from '@/lib/meal-plan';
import { generateMealPlan } from '@/ai/flows/generate-meal-plan-flow';
import { generateGroceryListBatched as generateGroceryList } from '@/ai/flows/generate-grocery-list-flow';
import { 
  startOfWeek, 
  addDays, 
  format, 
  addWeeks, 
  subWeeks, 
  parseISO 
} from 'date-fns';
import { 
  Plus, 
  Pencil, 
  Trash2, 
  ChevronLeft, 
  ChevronRight, 
  ChevronDown,
  Loader2, 
  ArrowLeft, 
  Sparkles, 
  Check,
  X,
  Save,
  ShoppingCart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { FoodDecorations } from '@/components/FoodDecorations';

const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const;
const MEALS = ['breakfast', 'lunch', 'dinner'] as const;

const CATEGORY_EMOJI: Record<string, string> = {
  'Vegetables': '🥬',
  'Fruits': '🍎',
  'Grains & Cereals': '🌾',
  'Lentils & Pulses': '🫘',
  'Dairy & Eggs': '🥛',
  'Meat & Poultry': '🍗',
  'Seafood': '🐟',
  'Spices & Masalas': '🌶️',
  'Oils & Condiments': '🫒',
  'Others': '📦',
};

function MealPlanContent() {
  const { user } = useUser();
  const { toast } = useToast();
  const router = useRouter();

  // ── STATE ──
  const [weekStart, setWeekStart] = useState<Date>(() => startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [plan, setPlan] = useState<WeeklyMealPlan | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  // AI Inputs
  const [dietType, setDietType] = useState<'Vegetarian' | 'Non-Vegetarian' | 'Mixed'>('Mixed');
  const [cuisinePreference, setCuisinePreference] = useState('');
  const [healthGoal, setHealthGoal] = useState<
    'No Preference' | 'Weight Loss' | 'Muscle Gain' | 
    'Diabetic Friendly' | 'Heart Healthy'
  >('No Preference');

  // Editing State
  const [editingSlot, setEditingSlot] = useState<{ day: typeof DAYS[number], meal: typeof MEALS[number] } | null>(null);
  const [editValue, setEditValue] = useState('');
  const [editServings, setEditServings] = useState<number>(2);
  const [editCuisine, setEditCuisine] = useState('');

  // Grocery List State
  const [grocerySections, setGrocerySections] = useState<GrocerySection[]>([]);
  const [isGeneratingGrocery, setIsGeneratingGrocery] = useState(false);
  const [groceryStartDay, setGroceryStartDay] = useState<typeof DAYS[number]>('monday');
  const [grocerySelectedDays, setGrocerySelectedDays] = useState<Set<number>>(new Set([0, 1, 2]));
  const [openSections, setOpenSections] = useState<Set<string>>(new Set());
  const [openCategories, setOpenCategories] = useState<Set<string>>(new Set());

  const weekStartDateStr = format(weekStart, 'yyyy-MM-dd');

  // ── DATA FETCHING ──
  useEffect(() => {
    const fetchPlan = async () => {
      if (!user) return;
      setIsLoading(true);
      try {
        const data = await getMealPlan(user.uid, weekStartDateStr);
        setPlan(data || { weekStartDate: weekStartDateStr });
        if (data?.grocerySections) {
          setGrocerySections(data.grocerySections);
        } else {
          setGrocerySections([]);
        }
        setOpenSections(new Set());
        setOpenCategories(new Set());
        setHasChanges(false);
      } catch (error) {
        console.error("Error fetching meal plan:", error);
        toast({ variant: "destructive", title: "Failed to load meal plan" });
      } finally {
        setIsLoading(false);
      }
    };
    fetchPlan();
  }, [user, weekStartDateStr, toast]);

  // ── ACTIONS ──
  const handleSave = async () => {
    if (!user || !plan) return;
    setIsSaving(true);
    try {
      await saveMealPlan(user.uid, plan);
      setHasChanges(false);
      toast({ title: "Meal plan saved! 🥗", description: "Your week is all planned out." });
    } catch (error) {
      toast({ variant: "destructive", title: "Error saving plan" });
    } finally {
      setIsSaving(false);
    }
  };

  const handleGenerateAI = async () => {
    setIsGenerating(true);
    try {
      const dishesArray: string[] = [];
      const result = await generateMealPlan({
        dietType,
        cuisinePreference: cuisinePreference || 'Mixed',
        specificDishes: dishesArray,
        healthGoal: healthGoal === 'No Preference' ? undefined : healthGoal,
      });

      const newPlan: WeeklyMealPlan = {
        weekStartDate: weekStartDateStr,
      };

      DAYS.forEach(day => {
        newPlan[day] = {
          breakfast: { dishName: result[day].breakfast, servings: 2, cuisine: cuisinePreference || 'Mixed' },
          lunch: { dishName: result[day].lunch, servings: 2, cuisine: cuisinePreference || 'Mixed' },
          dinner: { dishName: result[day].dinner, servings: 2, cuisine: cuisinePreference || 'Mixed' },
        };
      });

      setPlan(newPlan);
      setHasChanges(true);
      toast({ title: "Plan generated! ✨", description: "AI has filled your week." });
    } catch (error) {
      toast({ variant: "destructive", title: "Generation failed", description: "Please try again." });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateGroceryList = async () => {
    if (!plan || !user) return;

    const startIndex = DAYS.indexOf(groceryStartDay);
    const selectedDays = [0, 1, 2]
      .filter(offset => grocerySelectedDays.has(offset))
      .map(offset => DAYS[(startIndex + offset) % 7]);

    const daysKey = selectedDays.join(',');
    const daysLabel = selectedDays.map(d => 
      d.charAt(0).toUpperCase() + d.slice(1)
    ).join(' → ');

    const meals: { dishName: string; servings: number; cuisine: string }[] = [];

    selectedDays.forEach(day => {
      MEALS.forEach(meal => {
        const slot = plan[day]?.[meal];
        if (slot?.dishName) {
          meals.push({
            dishName: slot.dishName,
            servings: slot.servings || 2,
            cuisine: slot.cuisine || 'Mixed',
          });
        }
      });
    });

    if (meals.length === 0) {
      toast({ 
        variant: "destructive", 
        title: "No meals found", 
        description: `No meals planned for ${daysLabel}` 
      });
      return;
    }

    setIsGeneratingGrocery(true);
    try {
      const result = await generateGroceryList({ meals });
      
      const newSection: GrocerySection = {
        days: daysKey,
        daysLabel: daysLabel,
        items: result.items,
        generatedAt: Date.now(),
      };

      const updatedSections = grocerySections.filter(
        s => s.days !== daysKey
      );
      updatedSections.push(newSection);
      
      setGrocerySections(updatedSections);
      setOpenSections(new Set());
      setOpenCategories(new Set());

      await saveGroceryList(user.uid, weekStartDateStr, newSection, grocerySections);
      
      toast({ title: "Grocery list ready! 🛒" });
      setTimeout(() => {
        document.getElementById('grocery-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 200);
    } catch (error) {
      console.error('Grocery list error:', error);
      toast({ 
        variant: "destructive", 
        title: "Failed to generate grocery list", 
        description: String(error) 
      });
    } finally {
      setIsGeneratingGrocery(false);
    }
  };

  const toggleSection = (days: string) => {
    setOpenSections(prev => {
      const next = new Set(prev);
      if (next.has(days)) {
        next.delete(days);
      } else {
        next.add(days);
      }
      return next;
    });
  };

  const toggleCategory = (key: string) => {
    setOpenCategories(prev => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  const handleDeleteGrocerySection = async (days: string) => {
    if (!user) return;
    const updated = grocerySections.filter(s => s.days !== days);
    setGrocerySections(updated);
    try {
      await deleteGrocerySection(user.uid, weekStartDateStr, days, grocerySections);
      toast({ title: "Section removed 🗑️" });
    } catch (error) {
      toast({ variant: "destructive", title: "Failed to delete section" });
    }
  };

  const toggleGroceryDay = (offset: number) => {
    if (offset === 0) return; // starting day always selected
    setGrocerySelectedDays(prev => {
      const next = new Set(prev);
      if (next.has(offset)) {
        next.delete(offset);
      } else {
        next.add(offset);
      }
      return next;
    });
  };

  const updateSlot = (day: typeof DAYS[number], meal: typeof MEALS[number], slot: MealSlot | null) => {
    setPlan(prev => {
      if (!prev) return prev;
      const dayPlan = { ...(prev[day] || {}) };
      if (slot === null) {
        delete dayPlan[meal];
      } else {
        dayPlan[meal] = slot;
      }
      return { ...prev, [day]: dayPlan };
    });
    setHasChanges(true);
    setEditingSlot(null);
  };

  const startEditing = (day: typeof DAYS[number], meal: typeof MEALS[number], currentSlot?: MealSlot) => {
    setEditingSlot({ day, meal });
    setEditValue(currentSlot?.dishName || '');
    setEditServings(currentSlot?.servings || 2);
    setEditCuisine(currentSlot?.cuisine || '');
  };

  const weekRange = `${format(weekStart, 'MMM d')} – ${format(addDays(weekStart, 6), 'MMM d, yyyy')}`;

  return (
    <div className="relative min-h-screen overflow-hidden">
      <FoodDecorations />
      <div className="max-content px-4 py-8 relative z-10">
        
        {/* Navigation */}
        <Link 
          href="/"
          className="flex items-center gap-2 text-primary font-bold text-sm mb-6 hover:translate-x-[-4px] transition-transform w-fit"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Generator
        </Link>

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
          <div className="space-y-1">
            <h1 className="text-3xl font-extrabold tracking-tight text-foreground" style={{ fontFamily: "Inter, sans-serif", fontWeight: 800 }}>
              Weekly Meal Plan
            </h1>
            <p className="text-muted-foreground text-base">Plan your healthy meals for the week ahead</p>
          </div>

          <div className="flex items-center gap-4 bg-card border border-border p-2 rounded-xl shadow-sm">
            <Button variant="ghost" size="icon" onClick={() => setWeekStart(subWeeks(weekStart, 1))}>
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <span className="text-sm font-bold min-w-[180px] text-center">{weekRange}</span>
            <Button variant="ghost" size="icon" onClick={() => setWeekStart(addWeeks(weekStart, 1))}>
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* AI Generator Section */}
        <div className="bg-card border border-border rounded-2xl p-6 mb-8 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
            <Sparkles className="h-24 w-24 text-primary" />
          </div>
          <h2 className="text-lg font-bold flex items-center gap-2 mb-6">
            <Sparkles className="h-5 w-5 text-primary" />
            Generate Plan with AI
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
            <div className="space-y-3">
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Diet Type</label>
              <div className="flex gap-2">
                {(['Vegetarian', 'Non-Vegetarian', 'Mixed'] as const).map(type => (
                  <button
                    key={type}
                    onClick={() => setDietType(type)}
                    className={cn(
                      "text-xs px-3 py-2 rounded-md border font-medium flex-1 transition-all",
                      dietType === type 
                        ? "border-primary text-primary bg-primary/10" 
                        : "border-border text-muted-foreground hover:bg-secondary/50"
                    )}
                  >
                    {type === 'Non-Vegetarian' ? 'Non-Veg' : type}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Cuisine Preference</label>
              <Input 
                placeholder="e.g. Indian, Italian, Mixed" 
                value={cuisinePreference}
                onChange={(e) => setCuisinePreference(e.target.value)}
                className="h-10 text-sm"
              />
            </div>
            
            <div className="space-y-3">
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Health Goal
              </label>
              <div className="flex flex-wrap gap-2">
                {([
                  'No Preference',
                  'Weight Loss',
                  'Muscle Gain', 
                  'Diabetic Friendly',
                  'Heart Healthy'
                ] as const).map(goal => (
                  <button
                    key={goal}
                    onClick={() => setHealthGoal(goal)}
                    className={cn(
                      "text-xs px-3 py-2 rounded-md border font-medium transition-all",
                      healthGoal === goal
                        ? "border-primary text-primary bg-primary/10"
                        : "border-border text-muted-foreground hover:bg-secondary/50"
                    )}
                  >
                    {goal}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 flex justify-end">
            <Button 
              onClick={handleGenerateAI} 
              disabled={isGenerating}
              className="bg-primary hover:bg-primary/90 text-white font-bold h-11 px-8 rounded-xl gap-2 shadow-lg shadow-primary/20"
            >
              {isGenerating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              Generate Plan ✨
            </Button>
          </div>
        </div>

        {/* Meal Plan Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-10 mb-20">
            {/* Desktop Grid */}
            <div className="hidden lg:block overflow-x-auto">
              <div className="min-w-[1000px] bg-card border border-border rounded-2xl shadow-sm divide-y divide-border">
                {/* Header Row */}
                <div className="grid grid-cols-8 divide-x divide-border">
                  <div className="p-4 bg-secondary/5" />
                  {DAYS.map(day => (
                    <div key={day} className="p-4 text-center">
                      <span className="text-sm font-black uppercase tracking-widest text-foreground">{day}</span>
                    </div>
                  ))}
                </div>

                {/* Meal Rows */}
                {MEALS.map(meal => (
                  <div key={meal} className="grid grid-cols-8 divide-x divide-border" style={{ minHeight: '120px' }}>
                    <div className="p-4 bg-secondary/5 flex items-center justify-center border-r border-border">
                      <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground rotate-[-90deg] whitespace-nowrap">{meal}</span>
                    </div>
                    {DAYS.map(day => {
                      const dish = plan?.[day]?.[meal]?.dishName;
                      const isEditing = editingSlot?.day === day && editingSlot?.meal === meal;

                      return (
                        <div key={`${day}-${meal}`} className={cn("p-3 transition-colors relative group", dish && "bg-primary/[0.02]")}>
                          {isEditing ? (
                            <div className="space-y-2">
                              <Input 
                                autoFocus
                                value={editValue}
                                onChange={(e) => setEditValue(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && editValue.trim() && updateSlot(day, meal, { dishName: editValue.trim(), servings: editServings, cuisine: editCuisine })}
                                className="h-7 text-xs"
                                placeholder="Dish name..."
                              />
                              <div className="flex gap-1">
                                <Input
                                  type="number"
                                  min="1"
                                  max="20"
                                  value={editServings}
                                  onChange={(e) => setEditServings(parseInt(e.target.value) || 2)}
                                  className="h-7 text-xs w-16"
                                  placeholder="Srv"
                                  title="Servings"
                                />
                                <Input
                                  value={editCuisine}
                                  onChange={(e) => setEditCuisine(e.target.value)}
                                  className="h-7 text-xs flex-1"
                                  placeholder="Cuisine"
                                />
                              </div>
                              <div className="flex gap-1 justify-end">
                                <Button size="icon" variant="ghost" className="h-6 w-6 text-green-600" onClick={() => editValue.trim() && updateSlot(day, meal, { dishName: editValue.trim(), servings: editServings, cuisine: editCuisine })}>
                                  <Check className="h-3 w-3" />
                                </Button>
                                <Button size="icon" variant="ghost" className="h-6 w-6 text-destructive" onClick={() => setEditingSlot(null)}>
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          ) : dish ? (
                            <div className="h-full flex flex-col justify-between">
                              <div>
                                <button 
                                  onClick={() => {
                                    const slot = plan?.[day]?.[meal];
                                    router.push(`/?dish=${encodeURIComponent(slot?.dishName || '')}${slot?.servings ? `&servings=${slot.servings}` : ''}${slot?.cuisine ? `&cuisine=${encodeURIComponent(slot.cuisine)}` : ''}${healthGoal !== 'No Preference' ? `&goal=${encodeURIComponent(healthGoal)}` : ''}`);
                                  }}
                                  className="text-sm font-semibold text-foreground text-left hover:text-primary transition-colors line-clamp-2"
                                >
                                  {dish}
                                </button>
                                <div className="text-[10px] text-muted-foreground mt-1">
                                  {plan?.[day]?.[meal]?.servings && <span>{plan[day]![meal]!.servings} srv</span>}
                                  {plan?.[day]?.[meal]?.cuisine && <span> · {plan[day]![meal]!.cuisine}</span>}
                                </div>
                              </div>
                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-primary" onClick={() => startEditing(day, meal, plan?.[day]?.[meal])}>
                                  <Pencil className="h-3.5 w-3.5" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => updateSlot(day, meal, null)}>
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <div className="h-full flex items-center justify-center">
                              <Button 
                                variant="ghost" 
                                className="text-xs text-muted-foreground hover:text-primary gap-1.5 h-8 border border-dashed border-border"
                                onClick={() => startEditing(day, meal)}
                              >
                                <Plus className="h-3 w-3" /> Add Meal
                              </Button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>

            {/* Mobile / Tablet Vertical List */}
            <div className="lg:hidden space-y-6">
              {DAYS.map(day => (
                <div key={day} className="bg-card border border-border rounded-xl p-5 shadow-sm">
                  <h3 className="text-base font-black uppercase tracking-widest text-foreground mb-4 border-b border-border pb-3 flex items-center justify-between">
                    {day}
                    <span className="text-[10px] text-muted-foreground font-medium">Week of {weekStartDateStr}</span>
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    {MEALS.map(meal => {
                      const dish = plan?.[day]?.[meal]?.dishName;
                      const isEditing = editingSlot?.day === day && editingSlot?.meal === meal;

                      return (
                        <div key={`${day}-${meal}`} className="flex flex-col gap-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground ml-1">{meal}</span>
                          <div className={cn(
                            "min-h-[60px] rounded-lg border border-border flex items-center px-4 py-3",
                            dish ? "bg-primary/[0.03] border-primary/20" : "bg-secondary/10 border-dashed"
                          )}>
                            {isEditing ? (
                              <div className="flex flex-col gap-2 w-full">
                                <Input 
                                  autoFocus
                                  value={editValue}
                                  onChange={(e) => setEditValue(e.target.value)}
                                  className="h-10 text-sm"
                                  placeholder="Dish name..."
                                />
                                <div className="flex gap-2">
                                  <Input
                                    type="number"
                                    min="1"
                                    max="20"
                                    value={editServings}
                                    onChange={(e) => setEditServings(parseInt(e.target.value) || 2)}
                                    className="h-10 text-sm w-20"
                                    placeholder="Servings"
                                  />
                                  <Input
                                    value={editCuisine}
                                    onChange={(e) => setEditCuisine(e.target.value)}
                                    className="h-10 text-sm flex-1"
                                    placeholder="Cuisine"
                                  />
                                </div>
                                <div className="flex gap-1 justify-end">
                                  <Button size="icon" className="h-10 w-10 bg-green-600" onClick={() => editValue.trim() && updateSlot(day, meal, { dishName: editValue.trim(), servings: editServings, cuisine: editCuisine })}>
                                    <Check className="h-4 w-4" />
                                  </Button>
                                  <Button size="icon" variant="outline" className="h-10 w-10 border-destructive text-destructive" onClick={() => setEditingSlot(null)}>
                                    <X className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ) : dish ? (
                              <div className="flex items-center justify-between w-full">
                                <div className="flex-1">
                                  <button 
                                    onClick={() => {
                                      const slot = plan?.[day]?.[meal];
                                      router.push(`/?dish=${encodeURIComponent(slot?.dishName || '')}${slot?.servings ? `&servings=${slot.servings}` : ''}${slot?.cuisine ? `&cuisine=${encodeURIComponent(slot.cuisine)}` : ''}${healthGoal !== 'No Preference' ? `&goal=${encodeURIComponent(healthGoal)}` : ''}`);
                                    }}
                                    className="text-sm font-bold text-foreground hover:text-primary transition-colors text-left line-clamp-2"
                                  >
                                    {dish}
                                  </button>
                                  <div className="text-[10px] text-muted-foreground mt-0.5">
                                    {plan?.[day]?.[meal]?.servings && <span>{plan[day]![meal]!.servings} srv</span>}
                                    {plan?.[day]?.[meal]?.cuisine && <span> · {plan[day]![meal]!.cuisine}</span>}
                                  </div>
                                </div>
                                <div className="flex gap-1 ml-4 shrink-0">
                                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={() => startEditing(day, meal, plan?.[day]?.[meal])}>
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => updateSlot(day, meal, null)}>
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <Button 
                                variant="ghost" 
                                className="w-full text-xs text-muted-foreground hover:text-primary gap-2 h-10 border-none"
                                onClick={() => startEditing(day, meal)}
                              >
                                <Plus className="h-4 w-4" /> Add Meal
                              </Button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {/* Grocery List Section */}
            <div id="grocery-section" className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
              <div className="p-6 border-b border-border">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-primary/10 p-2.5 rounded-xl">
                      <ShoppingCart className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h2 className="text-lg font-bold text-foreground">Weekly Grocery List</h2>
                      <p className="text-xs text-muted-foreground">Generate grocery list for 3 days at a time</p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Starting from</label>
                    <div className="flex gap-1.5 flex-wrap mb-2">
                      {DAYS.map(day => (
                        <button
                          key={day}
                          onClick={() => {
                            setGroceryStartDay(day);
                            setGrocerySelectedDays(new Set([0, 1, 2]));
                          }}
                          className={cn(
                            "text-[11px] px-2.5 py-1.5 rounded-md border font-semibold uppercase tracking-wider transition-all",
                            day === groceryStartDay
                              ? "border-primary text-white bg-primary"
                              : "border-border text-muted-foreground hover:bg-secondary/50"
                          )}
                        >
                          {day.slice(0, 3)}
                        </button>
                      ))}
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      {[0, 1, 2].map(offset => {
                        const startIndex = DAYS.indexOf(groceryStartDay);
                        const day = DAYS[(startIndex + offset) % 7];
                        const isSelected = grocerySelectedDays.has(offset);
                        const isStart = offset === 0;

                        return (
                          <div
                            key={offset}
                            onClick={() => toggleGroceryDay(offset)}
                            className={cn(
                              "relative flex items-center gap-2 px-4 py-2.5 rounded-xl border-2 cursor-pointer transition-all select-none",
                              isSelected
                                ? "border-primary bg-primary/10 text-primary"
                                : "border-border bg-secondary/10 text-muted-foreground opacity-50"
                            )}
                          >
                            <span className="text-sm font-bold capitalize">
                              {day}
                            </span>
                            {isSelected && !isStart && (
                              <span
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleGroceryDay(offset);
                                }}
                                className="text-primary/60 hover:text-destructive transition-colors text-xs font-bold"
                              >
                                ×
                              </span>
                            )}
                            {isStart && isSelected && (
                              <span className="text-primary/40 text-xs">✓</span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                    <p className="text-[11px] text-muted-foreground">
                      Generating for: {[0, 1, 2]
                        .filter(offset => grocerySelectedDays.has(offset))
                        .map(offset => {
                          const startIndex = DAYS.indexOf(groceryStartDay);
                          const d = DAYS[(startIndex + offset) % 7];
                          return d.charAt(0).toUpperCase() + d.slice(1);
                        })
                        .join(' → ')
                      }
                    </p>
                  </div>

                  <Button
                    onClick={handleGenerateGroceryList}
                    disabled={isGeneratingGrocery}
                    className="bg-primary hover:bg-primary/90 text-white font-bold h-10 px-6 rounded-xl gap-2"
                  >
                    {isGeneratingGrocery ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShoppingCart className="h-4 w-4" />}
                    {isGeneratingGrocery ? 'Generating...' : grocerySections.length > 0 ? 'Generate More' : 'Generate List'}
                  </Button>
                </div>
              </div>

              {isGeneratingGrocery && (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              )}

              {grocerySections.length > 0 && !isGeneratingGrocery && (
                <div className="divide-y divide-border">
                  {grocerySections
                    .sort((a, b) => a.generatedAt - b.generatedAt)
                    .map((section) => {
                      const isSectionOpen = openSections.has(section.days);

                      const categoryOrder = [
                        'Vegetables', 'Fruits', 'Grains & Cereals',
                        'Lentils & Pulses', 'Dairy & Eggs',
                        'Meat & Poultry', 'Seafood',
                        'Spices & Masalas', 'Oils & Condiments', 'Others',
                      ];

                      const grouped = categoryOrder.reduce((acc, cat) => {
                        const items = section.items.filter(item => item.category === cat);
                        if (items.length > 0) acc[cat] = items;
                        return acc;
                      }, {} as Record<string, GroceryItem[]>);

                      return (
                        <div key={section.days}>
                          <div className="flex items-center">
                            <button
                              onClick={() => toggleSection(section.days)}
                              className="flex-1 px-6 py-4 flex items-center justify-between hover:bg-secondary/5 transition-colors"
                            >
                              <div className="flex items-center gap-3">
                                <ShoppingCart className="h-4 w-4 text-primary" />
                                <span className="text-sm font-bold text-foreground">
                                  {section.daysLabel}
                                </span>
                                <span className="text-xs font-medium text-muted-foreground bg-secondary/50 px-2 py-0.5 rounded-full">
                                  {section.items.length} items
                                </span>
                              </div>
                              <ChevronDown className={cn(
                                "h-4 w-4 text-muted-foreground transition-transform duration-200",
                                isSectionOpen && "rotate-180"
                              )} />
                            </button>
                            <button
                              onClick={() => handleDeleteGrocerySection(section.days)}
                              className="px-4 py-4 text-muted-foreground hover:text-destructive transition-colors"
                              title="Delete this section"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>

                          {isSectionOpen && (
                            <div className="border-t border-border/50 pl-4">
                              {Object.entries(grouped).map(([category, items]) => {
                                const catKey = `${section.days}-${category}`;
                                const isCatOpen = openCategories.has(catKey);

                                return (
                                  <div key={catKey}>
                                    <button
                                      onClick={() => toggleCategory(catKey)}
                                      className="w-full px-6 py-3 flex items-center justify-between hover:bg-secondary/5 transition-colors"
                                    >
                                      <div className="flex items-center gap-2">
                                        <span className="text-base">
                                          {CATEGORY_EMOJI[category] || '📦'}
                                        </span>
                                        <span className="text-xs font-bold text-foreground">
                                          {category}
                                        </span>
                                        <span className="text-[10px] font-medium text-muted-foreground bg-secondary/50 px-1.5 py-0.5 rounded-full">
                                          {items.length}
                                        </span>
                                      </div>
                                      <ChevronDown className={cn(
                                        "h-3 w-3 text-muted-foreground transition-transform duration-200",
                                        isCatOpen && "rotate-180"
                                      )} />
                                    </button>

                                    {isCatOpen && (
                                      <div className="border-t border-border/30">
                                        {items.map((item, index) => (
                                          <div
                                            key={index}
                                            className="flex items-start px-6 pl-16 py-2.5 hover:bg-secondary/5 transition-colors border-b border-border/20 last:border-b-0"
                                          >
                                            <div className="flex-1">
                                              <div className="flex items-center gap-2 flex-wrap">
                                                <span className="text-sm font-semibold text-foreground">
                                                  {item.name}
                                                </span>
                                                <span className="text-[10px] font-bold text-primary bg-primary/10 px-1.5 py-0.5 rounded-full">
                                                  {item.quantity}
                                                </span>
                                              </div>
                                              <div className="text-[10px] text-muted-foreground mt-0.5">
                                                For: {item.neededFor.join(', ')}
                                              </div>
                                            </div>
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}

                  <div className="px-6 py-3 bg-secondary/5">
                    <p className="text-[11px] text-muted-foreground font-medium">
                      {grocerySections.length} {grocerySections.length === 1 ? 'section' : 'sections'} · {grocerySections.reduce((sum, s) => sum + s.items.length, 0)} total items
                    </p>
                  </div>
                </div>
              )}

              {grocerySections.length === 0 && !isGeneratingGrocery && (
                <div className="flex flex-col items-center justify-center py-12 text-center px-6">
                  <ShoppingCart className="h-10 w-10 text-muted-foreground/20 mb-3" />
                  <p className="text-sm text-muted-foreground">
                    Select starting day and click "Generate List" to get your grocery list
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Action Button - Floating/Fixed */}
        <div className="fixed bottom-8 right-8 z-[40]">
          <Button 
            size="lg"
            disabled={!hasChanges || isSaving}
            onClick={handleSave}
            className={cn(
              "h-14 px-8 rounded-full shadow-2xl font-bold gap-3 transition-all transform hover:scale-105 active:scale-95",
              hasChanges ? "bg-primary text-white" : "bg-muted text-muted-foreground cursor-not-allowed border border-border"
            )}
          >
            {isSaving ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
            {isSaving ? "Saving..." : "Save Plan"}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function MealPlanPage() {
  return (
    <ProtectedRoute>
      <Suspense fallback={
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      }>
        <MealPlanContent />
      </Suspense>
    </ProtectedRoute>
  );
}
